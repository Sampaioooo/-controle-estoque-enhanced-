document.addEventListener("DOMContentLoaded", () => {
  configurarNotificacoes();
  carregarProdutos();
  configurarPesquisa();
  carregarMovimentacoes();

  const botaoCadastro = document.querySelector(".content-button");
  botaoCadastro.addEventListener("click", () => {
    const formExistente = document.querySelector("#form-produto");
    if (!formExistente) exibirFormularioCadastroNaTela();
  });
});

function configurarNotificacoes() {
  const notIcon = document.querySelector(".notification");
  if (notIcon) {
    notIcon.addEventListener("click", async () => {
      const resposta = await fetch("/produtos/alerta/baixo-estoque");
      const produtos = await resposta.json();
      if (!produtos.length) return alert("Nenhum produto com estoque baixo.");
      const lista = produtos.map(p => `- ${p.nome} (Qtd: ${p.quantidade})`).join("\n");
      alert("Produtos com estoque baixo:\n" + lista);
    });
  }
}

function configurarPesquisa() {
  const searchInput = document.querySelector(".search-bar input");
  searchInput.addEventListener("input", () => {
    const termo = searchInput.value.toLowerCase();
    const cards = document.querySelectorAll(".adobe-product");
    cards.forEach((card) => {
      const nome = card.textContent.toLowerCase();
      card.style.display = nome.includes(termo) ? "" : "none";
    });
  });
}

function exibirFormularioCadastroNaTela() {
  const areaCadastro = document.querySelector(".content-wrapper-context");
  const form = document.createElement("form");
  form.id = "form-produto";
  form.style.marginTop = "20px";
  form.innerHTML = `
    <input type="text" id="nome" placeholder="Nome do Produto" required><br><br>
    <input type="number" id="preco" placeholder="Preço (R$)" required><br><br>
    <input type="number" id="quantidade" placeholder="Quantidade" required><br><br>
    <input type="text" id="categoria" placeholder="Categoria" required><br><br>
    <button type="submit" class="content-button">Salvar</button>
  `;
  areaCadastro.appendChild(form);

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const novoProduto = {
      nome: form.nome.value,
      preco: parseFloat(form.preco.value),
      quantidade: parseInt(form.quantidade.value),
      categoria: form.categoria.value,
    };
    try {
      const res = await fetch("/produtos", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(novoProduto),
      });
      const produtoCriado = await res.json();

      // ALERTA automático com botão
      if (novoProduto.quantidade < 10) {
        const alerta = document.getElementById("alertaEstoque");
        alerta.innerHTML = `⚠ Produto <strong>"${novoProduto.nome}"</strong> está com estoque abaixo do mínimo!
          <br><br><button onclick="destacarProduto('${novoProduto.nome}')" class="content-button">OK</button>`;
        alerta.style.display = "block";
      }

      // MOVIMENTAÇÃO automática
      await fetch("/movimentacoes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          tipo: "Cadastro",
          produto: novoProduto.nome,
          quantidade: novoProduto.quantidade,
        }),
      });

      alert("Produto cadastrado com sucesso!");
      form.remove();
      carregarProdutos();
      carregarMovimentacoes();
    } catch (err) {
      alert("Erro ao cadastrar produto.");
    }
  });
}

function destacarProduto(nome) {
  const produtos = document.querySelectorAll(".adobe-product");
  produtos.forEach(prod => {
    if (prod.innerText.includes(nome)) {
      prod.scrollIntoView({ behavior: "smooth", block: "center" });
      prod.style.border = "2px solid yellow";
      setTimeout(() => {
        prod.style.border = "";
      }, 3000);
    }
  });
  document.getElementById("alertaEstoque").style.display = "none";
}

async function carregarProdutos() {
  try {
    const resposta = await fetch("/produtos");
    const produtos = await resposta.json();
    const container = document.querySelector("#lista-produtos");
    container.innerHTML = "";

    produtos.forEach((produto) => {
      const card = document.createElement("li");
      card.classList.add("adobe-product");
      card.innerHTML = `
        <div class="products">
          <p><strong>Produto:</strong> ${produto.nome}</p>
          <p><strong>Preço:</strong> R$ ${produto.preco.toFixed(2)}</p>
          <p><strong>Quantidade:</strong> ${produto.quantidade}</p>
          <p><strong>Categoria:</strong> ${produto.categoria}</p>
        </div>
        <div class="button-wrapper">
          <button class="content-button status-button open" onclick="exibirFormularioEdicao(${produto.id}, '${produto.nome}')">Modificar</button>
          <button class="content-button status-button open" onclick="deletarProduto(${produto.id}, '${produto.nome}')">Excluir</button>
        </div>
      `;
      container.appendChild(card);
    });
  } catch (err) {
    console.error("Erro ao carregar produtos:", err);
  }
}

function exibirFormularioEdicao(id, nomeProduto) {
  fetch(`/produtos`)
    .then(res => res.json())
    .then(produtos => {
      const produto = produtos.find(p => p.id === id);
      if (!produto) return alert("Produto não encontrado");

      const formPopup = document.createElement("div");
      formPopup.className = "popup-form";
      Object.assign(formPopup.style, {
        position: "fixed",
        top: "50%",
        left: "50%",
        transform: "translate(-50%, -50%)",
        zIndex: "999",
        background: "#111827",
        padding: "20px",
        borderRadius: "10px",
        boxShadow: "0 0 20px rgba(0, 0, 0, 0.3)",
      });
      formPopup.innerHTML = `
        <div class="form-container">
          <h3>Modificar Produto</h3>
          <form id="form-editar">
            <input type="text" id="nome" value="${produto.nome}" required><br><br>
            <input type="number" id="preco" value="${produto.preco}" required><br><br>
            <input type="number" id="quantidade" value="${produto.quantidade}" required><br><br>
            <input type="text" id="categoria" value="${produto.categoria}" required><br><br>
            <button type="submit" class="content-button">Atualizar</button>
            <button type="button" class="content-button" onclick="document.body.removeChild(this.closest('.popup-form'))">Cancelar</button>
          </form>
        </div>
      `;
      document.body.appendChild(formPopup);

      const form = formPopup.querySelector("#form-editar");
      form.addEventListener("submit", async (e) => {
        e.preventDefault();
        const dadosAtualizados = {
          nome: form.nome.value,
          preco: parseFloat(form.preco.value),
          quantidade: parseInt(form.quantidade.value),
          categoria: form.categoria.value,
        };
        try {
          await fetch(`/produtos/${id}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(dadosAtualizados),
          });

          // Registro movimentação
          await fetch("/movimentacoes", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              tipo: "Modificação",
              produto: nomeProduto,
              quantidade: dadosAtualizados.quantidade,
            }),
          });

          alert("Produto atualizado!");
          document.body.removeChild(formPopup);
          carregarProdutos();
          carregarMovimentacoes();
        } catch (err) {
          alert("Erro ao atualizar produto.");
        }
      });
    });
}

async function deletarProduto(id, nomeProduto) {
  if (confirm("Tem certeza que deseja excluir este produto?")) {
    try {
      await fetch(`/produtos/${id}`, { method: "DELETE" });

      // Registrar movimentação
      await fetch("/movimentacoes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          tipo: "Exclusão",
          produto: nomeProduto,
          quantidade: 0
        }),
      });

      carregarProdutos();
      carregarMovimentacoes();
    } catch (err) {
      alert("Erro ao excluir produto");
    }
  }
}

async function carregarMovimentacoes() {
  try {
    const resposta = await fetch("/movimentacoes");
    const movimentacoes = await resposta.json();
    localStorage.setItem("movimentacoes", movimentacoes.map(m =>
      `${m.tipo} | ${m.produto} | ${m.quantidade} un. | ${new Date(m.dataHora).toLocaleString()}`
    ).join('\n'));
  } catch (err) {
    console.error("Erro ao carregar movimentações:", err);
  }
}

// Modo Noturno
const toggleButton = document.querySelector('.dark-light');
toggleButton.addEventListener('click', () => {
  document.body.classList.toggle('light-mode');
});
