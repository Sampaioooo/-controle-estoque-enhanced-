const express = require('express');
const path = require('path');
const cors = require('cors');
const app = express();

const produtoRoutes = require('./routes/produtoRoutes');
const movimentacaoRoutes = require('./routes/movimentacaoRoutes');

app.use(express.json());
app.use(cors());
//  Serve o HTML e arquivos estáticos do front-end
app.use(express.static(path.join(__dirname, 'public')));

app.use('/produtos', produtoRoutes);
app.use('/movimentacoes', movimentacaoRoutes);

module.exports = app;

